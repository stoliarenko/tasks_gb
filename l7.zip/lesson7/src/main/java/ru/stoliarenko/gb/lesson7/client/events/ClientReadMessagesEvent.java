package ru.stoliarenko.gb.lesson7.client.events;

public final class ClientReadMessagesEvent {

}
