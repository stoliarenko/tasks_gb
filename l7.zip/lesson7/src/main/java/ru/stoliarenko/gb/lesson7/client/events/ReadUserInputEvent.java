package ru.stoliarenko.gb.lesson7.client.events;

public class ReadUserInputEvent {

}
