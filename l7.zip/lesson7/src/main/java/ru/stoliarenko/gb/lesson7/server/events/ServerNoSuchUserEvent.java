package ru.stoliarenko.gb.lesson7.server.events;

public final class ServerNoSuchUserEvent {

}
