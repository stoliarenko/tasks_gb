package ru.stoliarenko.gb.lesson7.model;

public final class MessageUserAccepted extends Message {

    {
        setType(MessageType.USER_ACCEPTED);
    }
}
