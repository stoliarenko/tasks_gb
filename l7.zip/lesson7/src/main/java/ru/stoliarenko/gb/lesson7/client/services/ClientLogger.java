package ru.stoliarenko.gb.lesson7.client.services;

public class ClientLogger {
    public static void writeMessage(String text) {
        System.out.println(text);
    }
}
