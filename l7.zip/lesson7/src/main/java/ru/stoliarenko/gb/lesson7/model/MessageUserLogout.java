package ru.stoliarenko.gb.lesson7.model;

public final class MessageUserLogout extends Message {
    {
        setType(MessageType.USER_LOGOUT);
    }
}
