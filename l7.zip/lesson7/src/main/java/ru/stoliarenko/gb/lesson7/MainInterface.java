package ru.stoliarenko.gb.lesson7;

public interface MainInterface {
    void run();
}
