package ru.stoliarenko.gb.cdi.events;

public final class AnotherEvent {

}
