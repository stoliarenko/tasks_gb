package ru.stoliarenko.gb.cdi.events;

import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class SomeEvent {

}
